<header>
    <a href="/">
        <h1>영화 게시판</h1>
    </a>
</header>  